package player;

import java.util.Scanner;
import java.util.Vector;

public class Main {
    public static void main(String[] args) {
        Vector<Giocatori> player=new Vector<>();
        int num=3;
    aggiungiGiocatore(num, player);


    }
    public static void aggiungiGiocatore(int num, Vector<Giocatori> player){
        Scanner Input=new Scanner(System.in);
        player.setSize(num);

        for (int i = 0; i < player.size(); i++) {
            Giocatori gioc = new Giocatori();
            gioc.setNome(Input.next());
            player.setElementAt(gioc, i);
        }
    }
}
